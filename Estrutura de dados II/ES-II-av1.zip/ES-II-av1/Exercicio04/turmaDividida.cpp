#include <iostream>
#include <vector>
#include <queue>
#include <climits> 
using namespace std;




// Url do problema :
// https://judge.beecrowd.com/pt/problems/view/3484
// SUBMISSÃO # 41875229





struct No {
    int chave;
    No* esquerda;
    No* direita;

    No(int chave) : chave(chave), esquerda(nullptr), direita(nullptr) {}
};

// função recursiva de iserir da BST - Estruturas I 
No* inserir(No* raiz, int chave) {
    if (!raiz) {
        return new No(chave); 
    }

    if (chave < raiz->chave) {
        raiz->esquerda = inserir(raiz->esquerda, chave);
    } else {
        raiz->direita = inserir(raiz->direita, chave);
    }

    return raiz;
}


// Materia apoio:
// https://pt.wikipedia.org/wiki/Busca_em_largura
// https://www.geeksforgeeks.org/bfs-vs-dfs-binary-tree/
// https://www.geeksforgeeks.org/level-order-tree-traversal/


void buscaEmLargura(No* raiz) {
    // Verifica se a árvore está vazia 
    if (raiz == NULL) {
        return;
    }

    // criamos uma fila que vai armazenar os nos
    queue<No*> fila; 
    fila.push(raiz); 

    // uso essa variavel p/ saber qual nivel da arv que estamos 
    int nivel = 0;  
    // Este loop continua até que a fila esteja vazia.
    // Enquanto houver nós a serem processados, o loop percorre a árvore nível por nível.
    while (!fila.empty()) {
        // ele guarda o n de nos em cada nivel 
        int tamanhoNivel = fila.size();
        // aqui eu armazeno o menor valor de chave do nivel atual
        // eu coloco o maior valor possivel pq ai eu sei qua qualquer chave vai ser menor que esse valor 
        int menorAltura = INT_MAX;
        // for para percorer todos os nos que estão no nivel atual 
        for (int i = 0; i < tamanhoNivel; i++) {
            // pego o primeiro no da fila
            No* atual = fila.front();
            // removo ele para depopis pegar o proximo 
            fila.pop();  

            // verificar se a chave do no atual é meno do que a menor chave encontrada nesse nivel 
            if (atual->chave < menorAltura) {
                // atualiza o menor valor 
                menorAltura = atual->chave;  
            }       
            // agr add os filhos desse no na fila, para fazer a verificação no proximo nível
            if (atual->esquerda != nullptr) {
                fila.push(atual->esquerda);  
            }
            // mesmo esquema que o if acima, se tiver filho a direita adiciona na fila
            if (atual->direita != nullptr) {
                fila.push(atual->direita);
            }
        }

        //apos percorrer todos os niveis imprime a menor altura
        cout << nivel << " " << menorAltura << endl;

        // incrementar o nivel para o proximo
        nivel++;
    }
}


int main() {
    int N;
    cin >> N;

    vector<int> alturas(N);
    for (int i = 0; i < N; i++) {
        cin >> alturas[i];
    }

    No* raiz = nullptr;
    for (int i = 0; i < N; i++) {
        raiz = inserir(raiz, alturas[i]);
    }

    buscaEmLargura(raiz);

    return 0;
}












































