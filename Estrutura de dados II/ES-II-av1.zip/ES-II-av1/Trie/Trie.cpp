#include "Trie.h"


// Mateirial de apoio :
// http://desenvolvendosoftware.com.br/estruturas-de-dados/tries.html#opera%C3%A7%C3%A3o-inserir
// https://portaldoprofessor.fct.unesp.br/projetos/cadilag/apps/structs/arv_trie.php
// https://marciobueno.com/arquivos/ensino/ed2/ED2_06_Trie_Patricia.pdf


Trie::Trie() {
    raiz = new No();
}

void Trie::inserir(string& palavra) {
    No* noAtual = raiz;
    for (char letra : palavra) {
        // eu uso isso pra saber se o caractere esta no intervalo [32, 126]
        if (letra < 32 || letra > 126) {
            // se entrar no if, o caractere é inavalido, e é ignora 
            return; 
        }

        // aqui eu verifico se o caractere existe, se não eu crio um novo no
        // como eu coloquei um map para guardar os filhos no noAtual fica mais facil encontrar eles com o find 
        if (noAtual->filhos.find(letra) == noAtual->filhos.end()) {
            // ai esse no atual recebe mais um filho com a letra que não existe 
            noAtual->filhos[letra] = new No();
        }
        noAtual = noAtual->filhos[letra];
    }
    noAtual->fimDaPalavra = true;   
}



void Trie::buscarComecandoPrefixo(string& prefixo) {
    No* noAtual = raiz;
    for (char letra : prefixo) {
        // se prefixo não foi encontrado, imprime q nõa encontrou
        if (noAtual->filhos.find(letra) == noAtual->filhos.end()) {
            cout << "Nenhuma senha encontrada com esse prefixo." << endl;
            return;
        }
    
        noAtual = noAtual->filhos[letra];
    }
    // vetor auxiliar para armazenar as senhas encontradas
    vector<string> resultados;
    auxBuscarSenhas(noAtual, prefixo, resultados);

    // aqui é so pra imprimir as senhas encontradas e a mensase de que nao foi encontrada
    if (resultados.empty()) {
        cout << "Nenhuma senha encontrada com esse prefixo." << endl;
    } else {
        //o for para percorer o vetor de resultados
        for (string& senha : resultados) {
            cout << senha << endl;
        }
    }
}



void Trie::auxBuscarSenhas(No* no, string& prefixo, vector<string>& resultados) {

    // uso isso para saber se o no atual marca o fim da palavra, se sim é valido 
    if (no->fimDaPalavra) {
        // add prefixo atual ao vetor de resultados.
        resultados.push_back(prefixo);  
    }
    // aqui eu percorro todos os filhos do no atual
    // que eu consigo pegar as sequencia ex: prefixo = 'gio' e pegando o filho posso encontrar 'vani' que ai eu adiciono e 
    // giovani no vetor de resultados
    for (auto& par : no->filhos) {
        // preciso disso pra a concatenação do prefixo com as proximas letras, isso vai expandir o prefixo 
        // exemplo: 'gio' + 'van' = 'giovan' + 'i' = 'giovani'
        // como to usando vetor, as chaves/letras eu uso o par.first
        // e o par.second e o no filho 
        string novoPrefixo = prefixo + par.first;
        auxBuscarSenhas(par.second, novoPrefixo, resultados);
    }
}








