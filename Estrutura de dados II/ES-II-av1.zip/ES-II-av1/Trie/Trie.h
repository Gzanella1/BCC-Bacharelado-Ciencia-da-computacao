#ifndef TRIE_H
#define TRIE_H

#include <iostream>
#include <map>
#include <string>
#include <vector>

using namespace std;

struct No {
    map<char, No*> filhos;  
    bool fimDaPalavra;          

    No() : fimDaPalavra(false) {}
}typedef No;

class Trie {
private:
    No* raiz;

public:
    Trie();                              
    void inserir(string& palavra); 
    void buscarComecandoPrefixo(string& prefixo); 
    void auxBuscarSenhas(No* no, string& prefixo, vector<string>& resultados);
};

#endif
