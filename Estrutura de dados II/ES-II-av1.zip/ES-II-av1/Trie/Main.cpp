#include <iostream>
#include <fstream>
#include "Trie.h"

using namespace std;

// Mateirial de apoio :
// http://desenvolvendosoftware.com.br/estruturas-de-dados/tries.html#opera%C3%A7%C3%A3o-inserir
// https://portaldoprofessor.fct.unesp.br/projetos/cadilag/apps/structs/arv_trie.php


int main() {
    Trie trie;

    // Abrindo o arquivo rockyou-menor.txt para ler as senhas
    ifstream arquivo("rockyou-menor.txt");
    string linha;


    // Insere cada palavra do arquivo na arvore 
    while (getline(arquivo, linha)) {
        trie.inserir(linha);
    }

    arquivo.close();

    string consulta;
    // Leitura de consultas até o fim do arquivo (EOF)
    while (getline(cin, consulta)) {
        trie.buscarComecandoPrefixo(consulta);
    }

    return 0;
}
