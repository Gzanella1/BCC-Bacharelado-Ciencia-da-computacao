#ifndef ARVOREB_H
#define ARVOREB_H


// Material de apoio :
// https://www.ic.unicamp.br/~rafael/cursos/2s2018/mc202/slides/unidade29-arvores-b.pdf 



struct No {
    // um no pode ter varias chaves, então tenho meio que uma lista de chaves 
    int* chaves;
    // essa parte aqui eu tive dificuldades 
    // aqui eu defino o grau minimo, que define as regras de chaves e filhos 
    // o no pode ter no maximo (2 * grauMinimo) - 1 chaves, e no minimo grauMinimo - 1 chaves
    // o numero de filhos em um nó
    int grauMinimo; 
    No **filhos;    
    // eu  uso isso pra saber quantos chaves tem em um determinado no 
    int numeroChaves; 
    bool ehFolha;   

    No(int grauMinimo, bool folha);  // Construtor do nós
};


class ArvoreB {
public:
    No *raiz; 
    int grauMinimo; 

    ArvoreB(int grauMinimo);

    void inserir(int chave);

    // essa função insere em um nó que não está cheio
    void inserirChaveNaoCheia(No* no, int chave);

    // função para dividir um filho cheio em dois
    void dividirFilho(No* no, int indice, No *filhoCheio);

    // função para percorrer e imprimir a árvore
    void percorrer(No* no);

    bool busca(int k);
    No* busca(No* no, int k);
};

#endif
