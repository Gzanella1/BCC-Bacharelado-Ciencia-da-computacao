#include <iostream>
#include "ArvoreB.h"
using namespace std;



// Material de apoio :
// https://www.ic.unicamp.br/~rafael/cursos/2s2018/mc202/slides/unidade29-arvores-b.pdf 





// Construtor do nó
No::No(int grauM, bool folha) {
    grauMinimo = grauM;           
    ehFolha = folha;          
    // guarda memoraia para o número de chaves
    chaves = new int[2 * grauMinimo - 1];
    
    // guarda memoria para os filhosn
    filhos = new No *[2 * grauMinimo];

    numeroChaves = 0; 
}

ArvoreB::ArvoreB(int grauM) {
    raiz = nullptr;   
    // Define o grau mínimo
    grauMinimo = grauM;  
}

void ArvoreB::percorrer(No* no) {
    // se a desgraça do nó for nula retorna nada e encerra a função
    if (no == nullptr) return;

    int i;
    // Percorre todas as chaves e filhos do nó
    for (i = 0; i < no->numeroChaves; i++) {
        // se o nó não é uma folha, significa que ele tem filhos
        if (!no->ehFolha){
            percorrer(no->filhos[i]); 
        } 
        //imprime chave
        cout << " " << no->chaves[i];  
    }
    // imprime o último filho, caso o nó não seja uma folha
    if (!no->ehFolha){
        percorrer(no->filhos[i]); 
    }
}

void ArvoreB::inserirChaveNaoCheia(No* no, int chave) {
    // inicializa o inidice, como o ultimo elemento da chave
    int i = no->numeroChaves - 1; 

    if (no->ehFolha) {
        // joga as chaves para a frente, q ai vai ter espaço para as novas chaves 
        while (i >= 0 && no->chaves[i] > chave) {
            no->chaves[i + 1] = no->chaves[i];
            i--;
        }
        // coloca a chave no lugar
        no->chaves[i + 1] = chave;
        // como na estrutura do no eu add uma chave então eu incremento o num de chaves
        no->numeroChaves ++;  
    } 
    else {
        // Se o nó não é folha, encontra o filho que vai receber a nova chave
        while (i >= 0 && no->chaves[i] > chave){
            i--;
        }
        // verifico se o filho está cheio, se ele estiver eu uso o metodo e divido o filho
        if (no->filhos[i + 1]->numeroChaves == 2 * grauMinimo - 1) {
            dividirFilho(no, i + 1, no->filhos[i + 1]);
            //decido em qual dos dois novos nós inserir a chave
            if (no->chaves[i + 1] < chave){
                i++;
            }
        }
        inserirChaveNaoCheia(no->filhos[i + 1], chave); 
    }
}


void ArvoreB::dividirFilho(No* no, int indice, No *filhoCheio) {
    // eu chamo essa função qundo um nó estiver cheio, 
    // que vai ser quando esse no não tem mais espaço para inseririr novas chaves


    No *novoNo = new No(filhoCheio->grauMinimo, filhoCheio->ehFolha);
    // novo no para armazenar t-1 chaves do no filhoCheio
    novoNo->numeroChaves = grauMinimo - 1;

    // Copia as últimas (t-1) chaves de filhoCheio para novoNo
    for (int j = 0; j < grauMinimo - 1; j++){
        novoNo->chaves[j] = filhoCheio->chaves[j + grauMinimo];
    }
    // copia os filhos do no filhoCheio para o novo no , se não for folha 
    if (!filhoCheio->ehFolha) {
        for (int j = 0; j < grauMinimo; j++){
            novoNo->filhos[j] = filhoCheio->filhos[j + grauMinimo];
        }
    }
    filhoCheio->numeroChaves = grauMinimo - 1;

    for (int j = no->numeroChaves; j >= indice + 1; j--)
        no->filhos[j + 1] = no->filhos[j];

    no->filhos[indice + 1] = novoNo;

    for (int j = no->numeroChaves - 1; j >= indice; j--)
        no->chaves[j + 1] = no->chaves[j];

    no->chaves[indice] = filhoCheio->chaves[grauMinimo - 1];
    no->numeroChaves++;
}

void ArvoreB::inserir(int chave) {

    if (raiz == nullptr) {
        raiz = new No(grauMinimo, true);
        // insere a chave 
        raiz->chaves[0] = chave; 
        // e aumenta o número de chaves
        raiz->numeroChaves = 1;  
    } else {

        // aqui eu to verificando se a raiz está cheia, se esntiver agente aumenta a arvore
        if (raiz->numeroChaves == 2 * grauMinimo - 1) {
            No *novoNo = new No(grauMinimo, false);
            novoNo->filhos[0] = raiz;

            // divide a antiga raiz e move uma chave para novoNo
            dividirFilho(novoNo, 0, raiz);

            int i = 0;
            if (novoNo->chaves[0] < chave){
                i++;
            }
            
            inserirChaveNaoCheia(novoNo->filhos[i], chave);
            // atualizar a nova raiz
            raiz = novoNo;
        } else {
            // Se a raiz não está cheia, insere diretamente
            inserirChaveNaoCheia(raiz, chave);
        }
    }
}



bool ArvoreB::busca(int chave) {
    No* resultado = (raiz == nullptr) ? nullptr : busca(raiz, chave);

    // se a raiz não for nulo chama o metodo busca auxiliar que recebe a raiz e a chave que eu vou buscar
    if(raiz != nullptr){
        resultado = busca(raiz, chave);
    }
    else{
        resultado = nullptr;
    }
    // retorna o resultado se ele não for nullo 
    return (resultado != nullptr); 
}

// essa função vai percorrer a árvore e retornar o nó que contém a chave
// eu uso essa função pra ser auxiliar ao metodo de busca
No* ArvoreB::busca(No* no, int chave) {
    int i = 0;
    int numChaves = no->numeroChaves; 

    while (i < numChaves && chave > no->chaves[i]){
        i++;
    }
    if (i < numChaves && no->chaves[i] == chave){
        return no;
    }
    if (no->ehFolha){
        return nullptr;
    }

    return busca(no->filhos[i], chave);
}
