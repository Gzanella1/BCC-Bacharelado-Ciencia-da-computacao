#include <iostream>
#include "ArvoreB.h"
using namespace std;


// Material de apoio :
// https://www.ic.unicamp.br/~rafael/cursos/2s2018/mc202/slides/unidade29-arvores-b.pdf 





int main() {
    // Cria uma árvore B com grau mínimo 3
    ArvoreB arvore(2);
    std::string comando;
    int valor;

    cout << "Comandos: insere <valor>, percorre, busca <valor>" << endl;

    // Menu conforme a entrada do usuario 
    // insere, percorre e busca precedido pelo valor 

    while (cin >> comando) {
        if (comando == "insere") {
            cin >> valor;
            arvore.inserir(valor);
        } 
        else if (comando == "percorre") {
            cout << "Percurso da árvore B em ordem: ";
            arvore.percorrer(arvore.raiz);
        }
        else if (comando == "busca") {
            cin >> valor;
            if (arvore.busca(valor)) {
                cout << "Valor " << valor << " encontrado!" <<  endl;
            } else {
                cout << "Valor " << valor << " não encontrado!" <<  endl;
            }
        }
    }

    return 0;
}
