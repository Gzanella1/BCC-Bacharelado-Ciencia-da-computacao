#include <iostream>
#include "RubroNegra.h"

// Material de apoio, livro do cormen visto em Estrutura I :
// https://computerscience360.wordpress.com/wp-content/uploads/2018/02/algoritmos-teoria-e-prc3a1tica-3ed-thomas-cormen.pdf



using namespace std;
int main() {
    RubroNegra arvore;

    // Criando alguns nós
    No* no1 = new No(12);
    No* no2 = new No(5);
    No* no3 = new No(15);
    No* no4 = new No(3);
    No* no5 = new No(10);
    No* no6 = new No(13);
    No* no7 = new No(17);
    No* no8 = new No(4);
    No* no9 = new No(7);
    No* no10 = new No(11);
    No* no11 = new No(14);
    No* no12 = new No(6);
    No* no13 = new No(8);

    //arvore.inserir(no1);
    arvore.inserir(no1);
    arvore.inserir(no2);
    arvore.inserir(no3);
    arvore.inserir(no4);
    arvore.inserir(no5);
    arvore.inserir(no6);
    arvore.inserir(no7);
    arvore.inserir(no8);
    arvore.inserir(no9);
    arvore.inserir(no10);
    arvore.inserir(no11);
    arvore.inserir(no12);
    arvore.inserir(no13);
   

    
    std:: cout << "Percurso em ordem: " ;
    arvore.imprimirEmOrdem(arvore.obterRaiz()); // Apenas chama a função
    std::cout << std::endl; 

    std:: cout << "Raiz: " << arvore.obterRaiz()->chave << endl; 


    std:: cout << "Altura: " << arvore.altura(arvore.obterRaiz()) << endl;
    std:: cout << "Quantidade de nós vermelhos :" << arvore.qtdNosVermelhos(arvore.obterRaiz()) << endl;
    std:: cout << "Quantidade de nós pretos: " << arvore.qtdNosPretos(arvore.obterRaiz()) << endl;


    return 0;
}       
