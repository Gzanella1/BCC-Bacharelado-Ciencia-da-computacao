#include <iostream>
#include <cstddef>
#include "RubroNegra.h"

// Constructor
RubroNegra::RubroNegra() : raiz(nullptr) {}

RubroNegra::~RubroNegra()
{
    // deleteArvore(raiz);
}

No *RubroNegra::obterRaiz()
{
    return raiz;
}

No *RubroNegra::valorMax(No *noX)
{
    while (noX->direita != nullptr)
    {
        noX = noX->direita;
    }
    return noX;
}

// INSERT DA ARVORE BST - SEMESTRE PASSADO

void RubroNegra::inserir(No *no)
{

    // ponteiro acompanhante  como pai de subTAux
    No *acom_PAI_ante = nullptr;
    // para percorer a arvore, e procura uma direção nula
    // ao final sub arvore fica null
    No *subArvore = raiz;

    // no while faz com que os dois ponteiros se desloquem para baixo da arvore
    // indo para esquerda ou direita ate subtAux ser igual a null
    // esse null vai ser onde o NO vai ser inserido, mas o subarvore não tem involvimento na inserção
    // subarvore so auxilia a procurar o lugar
    while (subArvore != nullptr)
    {
        // Atualiza o ponteiro acompanhante para o nó atual antes de descer na árvore

        // colocamos o acompanhante receber a subarvore pois quando a subarvore receber o null
        // o acompanhante vai ser o "pai" do suposto null exemplo:  no 15 aponta a esquerda para o nul
        // quero inserir o 13 então o 15 será o acompanhante e o 15.esquerda = null que será a subarvore
        acom_PAI_ante = subArvore;
        // verifica se é esquerda ou direita
        if (subArvore->chave > no->chave)
        {
            subArvore = subArvore->esquerda;
        }
        else
        {
            subArvore = subArvore->direita;
        }
    }
    // Define o pai do novo nó como o último nó não-nulo encontrado (acom_PAI_ante)
    // o no abaixo, ex "13" vai ser inserido em um dos lados do acompanhante ex:
    // acompanhante é 15 então 13 vai ser inserido a esquerda;
    no->pai = acom_PAI_ante;

    // se não tiver raiz, ou o pai desse no for null
    if (acom_PAI_ante == nullptr)
    {
        raiz = no;
    }
    // se não e null
    // então temos que inserir a esquerda ou a direita de acom_PAI_ante
    else if (acom_PAI_ante->chave > no->chave)
    {
        acom_PAI_ante->esquerda = no;
    }
    else
    {
        acom_PAI_ante->direita = no;
    }

    // Inicializa os filhos do novo nó como null
    no->esquerda = nullptr;
    no->direita = nullptr;
    // atribuir a cor vermelha como a regra
    no->cor = Cor::VERMELHO;

    // chamar o metodo para reorganizar a arvore
    corrigirDepoisDeInserir(no);
}


void RubroNegra::rotacaoEsquerda(No *noAtual)
{
    //---- desenhos graficos do passo a passo estão no notion -------

    // definir quem é a sub do no autal
    // variavel auxiliar que recebe a subarvore a direita do no atual
    No *subArvoreNoAtual = noAtual->direita;
    // Modifica o filho a direita do nó atual, tornando o filho a esquerda da subArvore como novo filho a direita do no atual
    noAtual->direita = subArvoreNoAtual->esquerda;
    // se o filho a esquerda da sub for diferente de null
    if (subArvoreNoAtual->esquerda != nullptr)
    {
        // teoricamente na linha acima ja definimos que noAtual ta apontanto para o filho a esquerda do sub, sendo não nulo ou nulo
        // então com o if sabemos que não é nulo, atualizamos o atributo desse filho a direita do sub
        // tornamos noAtual pai do sub-esque-pai;
        subArvoreNoAtual->esquerda->pai = subArvoreNoAtual;
    }
    // caso o noAtual não tenha pai
    if (noAtual->pai == nullptr)
    {
        // significa que ao invés de sub apontar para o pai do noAtual
        // sub será a nova raiz
        this->raiz = subArvoreNoAtual;
    }
    // caso noAtual tenha pai, e o noAtual for filho a esquerda de seu pai
    else if (noAtual == noAtual->pai->esquerda)
    {
        // então modificamos o atributo esquerdo do pai do no atual
        // na qual ele aponta para sub
        (noAtual->pai)->esquerda = subArvoreNoAtual;
    }
    // caso noAtual tenha pai, e o noAtual for filho a direita de seu pai
    else
    {
        (noAtual->pai)->direita = subArvoreNoAtual;
    }

    subArvoreNoAtual->esquerda = noAtual;
    noAtual->pai = subArvoreNoAtual;
}


// é a mesma logica da rotacao esquerda 
void RubroNegra::rotacaoDireita(No *noAtual)
{

    // subArovre a esquerda do no atual
    No *subArvoreNoAtual = noAtual->esquerda;
    // noAtual recebe como seu filho esquerdo, o filho direito da subarvore
    noAtual->esquerda = subArvoreNoAtual->direita;

    if (subArvoreNoAtual->direita != nullptr)
    {
        subArvoreNoAtual->direita->pai = subArvoreNoAtual;
    }

    if (noAtual->pai == nullptr)
    {
        this->raiz = subArvoreNoAtual;
    }
    else if (noAtual == noAtual->pai->esquerda)
    {
        noAtual->pai->esquerda = subArvoreNoAtual;
    }
    else
    {
        noAtual->pai->direita = subArvoreNoAtual;
    }
    subArvoreNoAtual->direita = noAtual;
    noAtual->pai = subArvoreNoAtual;
}

void RubroNegra::imprimirEmOrdem(No *noAtual)
{
    // std::cout << "imprimirEmOrdem\n";
    // Condição de parada: se noAtual for nullptr, não faz nada
    if (noAtual == nullptr)
    {
        return;
    }
    imprimirEmOrdem(noAtual->esquerda);
    cout << noAtual->chave << " ";
    imprimirEmOrdem(noAtual->direita);
}




// Esse metodo foi criado na aula 2 - parete 3 - Exercicios
int RubroNegra::altura(No *noAtual)
{
    if (noAtual == NULL || (noAtual->esquerda == NULL && noAtual->direita == NULL))
        return 0;
    else{  
        return (1 + max(altura(noAtual->esquerda), altura(noAtual->direita)));
    }
}





int RubroNegra::qtdNosVermelhos(No* noAtual) {
    // var aux para contar os nó vermelhos
    int num = 0; 

    // condição de parada da funç recursiva
    if (noAtual == nullptr) {
        return num; 
    }

    // seguir a mesma logica de imprimir inOrder esquerda- verifica a cor - direita
    // Contar nós vermelhos na subárvore à esquerd
    num += qtdNosVermelhos(noAtual->esquerda);
    
    // Verifica se o nó atual é vermelho
    if (noAtual->cor == Cor::VERMELHO) {
        num += 1; 
    }

    // Contar nós vermelhos na subárvore à direita
    num += qtdNosVermelhos(noAtual->direita);

    // retorna o número de nó vermelhos nas subarvores
    return num; 
}


int RubroNegra::qtdNosPretos(No* noAtual) {
    // iniciar a variavel para contar 
    int num = 0; 

    if (noAtual == nullptr) {
        return num;
    }
    // seguir a mesma logica de imprimir inOrder esquerda- verifica a cor - direita
    // contar sub arvore a esquerda 
    num += qtdNosPretos(noAtual->esquerda);
    // Verifica se o nó atual é preto
    if (noAtual->cor == Cor::PRETO) {
        num += 1; 
    }
    // Conta na sub arvore  direita
    num += qtdNosPretos(noAtual->direita);

    return num; 
}



void RubroNegra::corrigirDepoisDeInserir(No *noAtual)
{
    //  eu verifico se o pai não é nulo e se ele é vermelho pra continuar corrigindo
    while (noAtual->pai != nullptr && noAtual->pai->cor == Cor::VERMELHO)
    {
        // Se o pai for filho esquerdo do  noatual->pai->pai(avo) vou para a sub arvore 
        if (noAtual->pai == noAtual->pai->pai->esquerda)
        {
            // pego o filho direito do avô pra ver se ele interfere na cor
            No *sub = noAtual->pai->pai->direita;
            // se o tio for vermelho eu troco a cor para não dar erro na propr da arvore
            if (sub != nullptr && sub->cor == Cor::VERMELHO)
            {
                // o pai do no atual e o no "tio" fica preto, e o noatual->pai->pai(avo) fica vermelho
                noAtual->pai->cor = Cor::PRETO;
                sub->cor = Cor::PRETO;
                noAtual->pai->pai->cor = Cor::VERMELHO;
                
                noAtual = noAtual->pai->pai;
            }
            else
            {
                // se o noAtual for filho a direita agente tem que rotacionar a esquerda
                if (noAtual == noAtual->pai->direita)
                {
                    noAtual = noAtual->pai;
                    rotacaoEsquerda(noAtual); 
                }
                // depois de rotacionar eu modifico as cores 
                noAtual->pai->cor = Cor::PRETO;
                noAtual->pai->pai->cor = Cor::VERMELHO;
                
                rotacaoDireita(noAtual->pai->pai);
            }
        }
        else
        {
            // Se o pai for filho direto do  noatual->pai->pai(avo) vou para a sub arvore 
            No *sub = noAtual->pai->pai->esquerda;

            // verifico se o lado esquerdo não é nullo e se ele é vermelho
            if (sub != nullptr && sub->cor == Cor::VERMELHO){
               // o pai do no atual e o no "tio" fica preto, e o noatual->pai->pai(avo) fica vermelho
                noAtual->pai->cor = Cor::PRETO;
                sub->cor = Cor::PRETO;
                noAtual->pai->pai->cor = Cor::VERMELHO;
                noAtual = noAtual->pai->pai;
            }
            else
            {
                // se o noAtual for filho a esquerda agente tem que rotacionar a direita
                if (noAtual == noAtual->pai->esquerda)
                {
                    noAtual = noAtual->pai;
                    rotacaoDireita(noAtual); 
                }
                // ajustar as cores
                noAtual->pai->cor = Cor::PRETO;
                noAtual->pai->pai->cor = Cor::VERMELHO;
                rotacaoEsquerda(noAtual->pai->pai);
            }
        }
    }

    // noo final, garanto q a raiz sempre vai ser preta
    this->raiz->cor = Cor::PRETO;
}
