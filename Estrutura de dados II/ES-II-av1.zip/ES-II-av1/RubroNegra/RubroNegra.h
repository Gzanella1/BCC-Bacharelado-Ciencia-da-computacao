#ifndef RubroNegra_H
#define RubroNegra_H
using namespace std;


enum Cor { VERMELHO, PRETO };
struct No {
    int chave;
    No* esquerda;
    No* direita;
    No* pai;
    Cor cor;

  // Construtor
    No(int valor) 
        : chave(valor), esquerda(nullptr), direita(nullptr), pai(nullptr), cor(VERMELHO) // Inicia com cor vermelha
    {}

};

class RubroNegra{
public:
    No* raiz;

    RubroNegra();
    ~RubroNegra();

    No* obterRaiz();
    No* valorMax(No* noX);


    void imprimirEmOrdem(No* noAtual);
    void inserir(No* no);

    void rotacaoEsquerda(No* raiz);
    void rotacaoDireita(No *raiz);
    void corrigirDepoisDeInserir(No* noAtual);
    
    No* buscarNo(int chave);

    int altura(No* noAtual);
    int qtdNosVermelhos(No* noAtual);
    int qtdNosPretos(No* noAtual);
    

};
#endif // ARVOREBINARIA_H
