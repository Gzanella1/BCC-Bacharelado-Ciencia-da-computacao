# Futstats

Este repositório tem como objetivo concluir o trabalho final da matéria de Desenvolvimento Web do curso de Ciências da Computação do Instituto Federal Catarinense.
A ideia do projeto é fazer um site com as tabelas de vários campeonatos de futebol, e fazer simulação de partidas de futebol, consumindo uma API.

Feito por: Guilherme Serafin de Carvalho, Lucas Taveira de Sena e Giovani Zanella
