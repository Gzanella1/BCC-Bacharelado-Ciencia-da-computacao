<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        $x=["joão", "Tabata","carlos","Daniel"];
                
        unset($x[1]);
        //serve para apagar uma posição
        
        print_r($x);     
        //Função para ver o que cada posição guarda e a posição ocupada
        //Função para teste, programadores sempre usam
        
        
        
                
        ?>
    </body>
</html>
