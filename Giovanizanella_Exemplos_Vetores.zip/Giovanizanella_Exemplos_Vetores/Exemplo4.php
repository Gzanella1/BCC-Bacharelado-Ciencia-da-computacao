<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        //Atividade
       
        for($i=0;$i<=4;$i++){
            $v[$i]=$_GET["n$i"];
        }
        $max=  count($v);
        
        for($i=0;$i<$max;$i++){
            echo "$v[$i]";
        }
        ?>
    </body>
</html>
