<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
       //segunda foram de definir um vetor 
       $nome[0]= "joão";
       $nome[1]= "Tabata";
       $nome[2]= "Carlos";
       $nome[3]= "Daniel";
      
//       for($i=0;$i<4;$i++){
//           echo"$nome[$i]<br>";
//       }
       
       $nome[4]= "Artur";
       $nome[5]= "Gertrudes";
       
       $max =  count($nome); 
        //count da a quantidade de elementos dentro do array, e não aquantidade de posição 
       
       echo "No vetor nome há $max posições<br>";        
       
       for($i=0;$i<$max;$i++){
           echo"<br>$nome[$i]";
       }
        ?>
    </body>
</html>
