<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
       //primeira foram de definir um vetor 
       $vet= array(1,2,3,4,5,6);
       
       for($i=0;$i<=5;$i++){
          echo "$vet[$i]<br>";
       }
       
        ?>
    </body>
</html>
