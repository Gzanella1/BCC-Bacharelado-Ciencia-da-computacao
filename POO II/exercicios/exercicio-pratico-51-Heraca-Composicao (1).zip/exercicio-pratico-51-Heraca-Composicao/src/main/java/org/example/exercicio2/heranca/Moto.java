package org.example.exercicio2.heranca;

import org.example.exercicio1.heranca.Pessoa;

public class Moto extends Veiculo {
    private int cilindradas;
    private Pessoa proprietario; // Pessoa pode ser Vendedor ou Motorista

    public Moto(String placa, String cor, String modelo, int cilindradas, Pessoa proprietario) {
        super(placa, cor, modelo);
        this.cilindradas = cilindradas;
        this.proprietario = proprietario;
    }

    @Override
    public String toString() {
        return "Moto{" +
                "cilindradas=" + cilindradas +
                ", proprietario=" + proprietario +
                ", placa='" + placa + '\'' +
                ", cor='" + cor + '\'' +
                ", modelo='" + modelo + '\'' +
                '}';
    }

    public int getCilindradas() {
        return cilindradas;
    }

    public void setCilindradas(int cilindradas) {
        this.cilindradas = cilindradas;
    }

    public Pessoa getProprietario() {
        return proprietario;
    }

    public void setProprietario(Pessoa proprietario) {
        this.proprietario = proprietario;
    }
}
