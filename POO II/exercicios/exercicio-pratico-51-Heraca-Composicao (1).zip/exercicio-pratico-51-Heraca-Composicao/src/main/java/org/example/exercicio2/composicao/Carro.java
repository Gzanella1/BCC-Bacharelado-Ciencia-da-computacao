package org.example.exercicio2.composicao;


import org.example.exercicio1.composicao.Pessoa;

public class Carro {
    private Veiculo veiculo;
    private int numeroDeLugares;
    private String renavam;
    private Pessoa proprietario;

    public Carro(Veiculo veiculo, int numeroDeLugares, String renavam, Pessoa proprietario) {
        this.veiculo = veiculo;
        this.numeroDeLugares = numeroDeLugares;
        this.renavam = renavam;
        this.proprietario = proprietario;
    }

    @Override
    public String toString() {
        return "Carro{" +
                "veiculo=" + veiculo +
                ", numeroDeLugares=" + numeroDeLugares +
                ", renavam='" + renavam + '\'' +
                ", proprietario=" + proprietario +
                '}';
    }

    public Veiculo getVeiculo() {
        return veiculo;
    }

    public void setVeiculo(Veiculo veiculo) {
        this.veiculo = veiculo;
    }

    public int getNumeroDeLugares() {
        return numeroDeLugares;
    }

    public void setNumeroDeLugares(int numeroDeLugares) {
        this.numeroDeLugares = numeroDeLugares;
    }

    public String getRenavam() {
        return renavam;
    }

    public void setRenavam(String renavam) {
        this.renavam = renavam;
    }

    public Pessoa getProprietario() {
        return proprietario;
    }

    public void setProprietario(Pessoa proprietario) {
        this.proprietario = proprietario;
    }
}
