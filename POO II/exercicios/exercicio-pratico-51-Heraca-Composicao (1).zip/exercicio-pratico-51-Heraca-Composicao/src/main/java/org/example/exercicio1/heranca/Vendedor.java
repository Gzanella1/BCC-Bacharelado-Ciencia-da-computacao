package org.example.exercicio1.heranca;

public class Vendedor extends Pessoa {

    private double comissao;
    private String areaDeVendas;

    public Vendedor(String cpf, String nome, String email, String telefone, double comissao, String areaDeVendas) {
        super(cpf, nome, email, telefone);
        this.comissao = comissao;
        this.areaDeVendas = areaDeVendas;
    }

    @Override
    public String toString() {
        return "Vendedor{" +
                "cpf='" + getCpf() + '\'' +
                ", nome='" + getNome() + '\'' +
                ", email='" + getEmail() + '\'' +
                ", telefone='" + getTelefone() + '\'' +
                ", comissao=" + comissao +
                ", areaDeVendas='" + areaDeVendas + '\'' +
                '}';
    }

    // Métodos getters e setters para os atributos
    public double getComissao() {
        return comissao;
    }

    public void setComissao(double comissao) {
        this.comissao = comissao;
    }

    public String getAreaDeVendas() {
        return areaDeVendas;
    }

    public void setAreaDeVendas(String areaDeVendas) {
        this.areaDeVendas = areaDeVendas;
    }

    public double calcularSalario(double vendas) {
        return comissao * vendas;
    }
}
