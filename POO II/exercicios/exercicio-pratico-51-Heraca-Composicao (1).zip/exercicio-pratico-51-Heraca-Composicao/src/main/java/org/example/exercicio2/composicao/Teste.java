package org.example.exercicio2.composicao;

import org.example.exercicio1.composicao.Pessoa;

public class Teste {
        public static void main(String[] args) {
            Pessoa vendedor = new Pessoa("123.456.789-00", "João Silva", "joao.silva@email.com", "(47) 99999-9999");
            Pessoa motorista = new Pessoa("987.654.321-00", "Maria Oliveira", "maria.oliveira@email.com", "(47) 88888-8888");

            Veiculo veiculoCarro = new Veiculo("ABC1D23", "Preto", "Sedan");
            Veiculo veiculoMoto = new Veiculo("XYZ4W56", "Vermelho", "Esportiva");

            Carro carro = new Carro(veiculoCarro, 5, "1234567890123", vendedor );
            Moto moto = new Moto(veiculoMoto, 600, motorista);

            System.out.println("\n\n"+carro.toString());
            System.out.println("\n"+moto.toString());
    }

}
