package org.example.exercicio2.heranca;

import org.example.exercicio1.heranca.Motorista;
import org.example.exercicio1.heranca.Vendedor;

public class Teste {
    public static void main(String[] args) {
        Vendedor vendedor = new Vendedor("123.456.789-00", "João", "joao.silva@email.com", "(47) 99999-9999", 0.1, "Móveis");
        Motorista motorista = new Motorista("123.123.123-00", "Maria", "maria.oliveira@email.com", "(47) 88888-8888", "CNH123456", "2030-12-31");

        Carro carroDoVendedor = new Carro("AdddBC1D23", "Preto", "Sedan", 5, "1234567890123", vendedor);
        Moto motoDoMotorista = new Moto("XYZ4W56", "Vermelho", "Esportiva", 600, motorista);

        System.out.println("\n"+carroDoVendedor.toString()+"\n");
        System.out.println(motoDoMotorista.toString());

    }

}



