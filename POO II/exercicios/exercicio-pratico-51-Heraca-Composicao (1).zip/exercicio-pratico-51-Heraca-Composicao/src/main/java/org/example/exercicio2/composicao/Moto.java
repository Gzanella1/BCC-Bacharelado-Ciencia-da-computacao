package org.example.exercicio2.composicao;

import org.example.exercicio1.composicao.Pessoa;

public class Moto {

    private Veiculo veiculo;
    private int cilindradas;
    private Pessoa proprietario; // Pessoa pode ser Vendedor ou Motorista

    public Moto(Veiculo veiculo, int cilindradas, Pessoa proprietario) {
        this.veiculo = veiculo;
        this.cilindradas = cilindradas;
        this.proprietario = proprietario;
    }

    @Override
    public String toString() {
        return "Moto{" +
                "veiculo=" + veiculo +
                ", cilindradas=" + cilindradas +
                ", proprietario=" + proprietario +
                '}';
    }

    public Veiculo getVeiculo() {
        return veiculo;
    }

    public void setVeiculo(Veiculo veiculo) {
        this.veiculo = veiculo;
    }

    public int getCilindradas() {
        return cilindradas;
    }

    public void setCilindradas(int cilindradas) {
        this.cilindradas = cilindradas;
    }

    public Pessoa getProprietario() {
        return proprietario;
    }

    public void setProprietario(Pessoa proprietario) {
        this.proprietario = proprietario;
    }
}
