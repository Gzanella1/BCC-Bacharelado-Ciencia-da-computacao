package org.example.exercicio1.composicao;

public class Motorista {

    private Pessoa pessoa;
    private String numeroDaCnh;
    private String dataDeVencimentoDaCnh;

    public Motorista(Pessoa pessoa, String numeroDaCnh, String dataDeVencimentoDaCnh) {
        this.pessoa = pessoa;
        this.numeroDaCnh = numeroDaCnh;
        this.dataDeVencimentoDaCnh = dataDeVencimentoDaCnh;
    }

    @Override
    public String toString() {
        return "Motorista{" +
                "pessoa=" + pessoa +
                ", numeroDaCnh='" + numeroDaCnh + '\'' +
                ", dataDeVencimentoDaCnh='" + dataDeVencimentoDaCnh + '\'' +
                '}';
    }

    public Pessoa getPessoa() {
        return pessoa;
    }

    public void setPessoa(Pessoa pessoa) {
        this.pessoa = pessoa;
    }

    public String getNumeroDaCnh() {
        return numeroDaCnh;
    }

    public void setNumeroDaCnh(String numeroDaCnh) {
        this.numeroDaCnh = numeroDaCnh;
    }

    public String getDataDeVencimentoDaCnh() {
        return dataDeVencimentoDaCnh;
    }

    public void setDataDeVencimentoDaCnh(String dataDeVencimentoDaCnh) {
        this.dataDeVencimentoDaCnh = dataDeVencimentoDaCnh;
    }
}
