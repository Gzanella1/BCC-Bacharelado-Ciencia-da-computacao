package org.example.exercicio1.composicao;

public class Vendedor {

    private Pessoa pessoa;
    private double comissao;
    private String areaDeVendas;

    public Vendedor(Pessoa pessoa, double comissao, String areaDeVendas) {
        this.pessoa = pessoa;
        this.comissao = comissao;
        this.areaDeVendas = areaDeVendas;
    }

    @Override
    public String toString() {
        return "Vendedor{" +
                "pessoa=" + pessoa +
                ", comissao=" + comissao +
                ", areaDeVendas='" + areaDeVendas + '\'' +
                '}';
    }

    public Pessoa getPessoa() {
        return pessoa;
    }

    public void setPessoa(Pessoa pessoa) {
        this.pessoa = pessoa;
    }

    public double getComissao() {
        return comissao;
    }

    public void setComissao(double comissao) {
        this.comissao = comissao;
    }

    public String getAreaDeVendas() {
        return areaDeVendas;
    }

    public void setAreaDeVendas(String areaDeVendas) {
        this.areaDeVendas = areaDeVendas;
    }
}
