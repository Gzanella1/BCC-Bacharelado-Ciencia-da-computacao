package org.example.exercicio2.heranca;

import org.example.exercicio1.heranca.Pessoa;

public class Carro extends Veiculo{
    private int numeroDeLugares;
    private String renavam;
    private Pessoa proprietario; // Pessoa pode ser Vendedor ou Motorista

    public Carro(String placa, String cor, String modelo, int numeroDeLugares, String renavam, Pessoa proprietario) {
        super(placa, cor, modelo);
        this.numeroDeLugares = numeroDeLugares;
        this.renavam = renavam;
        this.proprietario = proprietario;
    }

    @Override
    public String toString() {
        return "Carro{" +
                "numeroDeLugares=" + numeroDeLugares +
                ", renavam='" + renavam + '\'' +
                ", proprietario=" + proprietario +
                ", placa='" + placa + '\'' +
                ", cor='" + cor + '\'' +
                ", modelo='" + modelo + '\'' +
                '}';
    }

    public int getNumeroDeLugares() {
        return numeroDeLugares;
    }

    public void setNumeroDeLugares(int numeroDeLugares) {
        this.numeroDeLugares = numeroDeLugares;
    }

    public String getRenavam() {
        return renavam;
    }

    public void setRenavam(String renavam) {
        this.renavam = renavam;
    }

    public Pessoa getProprietario() {
        return proprietario;
    }

    public void setProprietario(Pessoa proprietario) {
        this.proprietario = proprietario;
    }
}