package org.example.exercicio1.composicao;

public class Teste {
    public static void main(String[] args) {
        //criando uma pessoa
        Pessoa pessoaV1=new Pessoa("111.111.111-22", "pedro", "joao@gmail.com", "(47) 99999-9999");
        // setando essa pessoa como vendodor
        Vendedor v1 = new Vendedor(pessoaV1,0.1, "Eletrônicos");
        System.out.println(v1.toString());

        //criando uma pessoa
        Pessoa pessoaM1=new Pessoa("222.222.222-22", "Maria", "maria@gmail.com", "(47) 88888-8888");
        // setando essa pessoa como motorista
        Motorista m1 = new Motorista(pessoaM1, "123456789", "2025");
        System.out.println(m1.toString());
    }
}
