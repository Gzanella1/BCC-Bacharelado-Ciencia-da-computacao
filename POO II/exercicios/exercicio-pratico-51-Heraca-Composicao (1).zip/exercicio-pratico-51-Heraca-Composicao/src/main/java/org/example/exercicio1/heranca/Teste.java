package org.example.exercicio1.heranca;

public class Teste {
    public static void main(String[] args) {
        Vendedor v1 = new Vendedor("111.111.111-11", "João", "joao@gmail.com", "(47) 99999-9999", 0.1, "Eletrônicos");
        System.out.println(v1.toString());

        Motorista m1 = new Motorista("222.222.222-22", "Maria", "maria@gmail.com", "(47) 88888-8888", "123456789", "2025");
        System.out.println(m1.toString());
    }
}
