package org.example.exercicio1.heranca;
public class Motorista extends Pessoa{
    // Atributos específicos de um motorista
    private String numeroDaCnh;
    private String dataDeVencimentoDaCnh;

    public Motorista(String cpf, String nome, String email, String telefone, String numeroDaCnh, String dataDeVencimentoDaCnh) {
        super(cpf, nome, email, telefone); // Chamada ao construtor de Pessoa
        this.numeroDaCnh = numeroDaCnh;
        this.dataDeVencimentoDaCnh = dataDeVencimentoDaCnh;
    }

    @Override
    public String toString() {
        return "Motorista{" +
                "cpf='" + getCpf() + '\'' +
                ", nome='" + getNome() + '\'' +
                ", email='" + getEmail() + '\'' +
                ", telefone='" + getTelefone() + '\'' +
                ", numeroDaCnh='" + numeroDaCnh + '\'' +
                ", dataDeVencimentoDaCnh='" + dataDeVencimentoDaCnh + '\'' +
                '}';
    }

    public String getNumeroDaCnh() {
        return numeroDaCnh;
    }

    public void setNumeroDaCnh(String numeroDaCnh) {
        this.numeroDaCnh = numeroDaCnh;
    }

    public String getDataDeVencimentoDaCnh() {
        return dataDeVencimentoDaCnh;
    }

    public void setDataDeVencimentoDaCnh(String dataDeVencimentoDaCnh) {
        this.dataDeVencimentoDaCnh = dataDeVencimentoDaCnh;
    }

}
