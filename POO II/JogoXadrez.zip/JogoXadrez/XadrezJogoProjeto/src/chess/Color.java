package chess;

public enum Color {
    BRANCO,
    PRETO
}
