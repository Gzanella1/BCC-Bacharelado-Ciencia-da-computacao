package tests;

public class TestPiece {
}
