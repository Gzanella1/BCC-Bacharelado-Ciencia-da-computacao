# IFMOVE 

Biblioteca em C++ para movimentação em duas dimensões. Utiliza a biblioteca SDL2.

## Para gerar doxygem com documentação

make doc

## Para compilar os programas de teste

make
