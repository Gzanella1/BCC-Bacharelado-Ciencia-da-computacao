#include "graphics.h"


Graphics::~Graphics()
{
}

void Graphics::draw(Window &w)
{

}


