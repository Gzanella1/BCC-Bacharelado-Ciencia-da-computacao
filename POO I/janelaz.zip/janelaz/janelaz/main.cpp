#include <cmath>
#include <iostream>
using namespace std;

#include "window.h"
#include "sdl.h"
#include "triangle.h"
#include "rectangle.h"
#include "grid.h"
#include "circle.h"
#include "arrow2.h"
#include "vector2.h"

#define WIDTH 800
#define HEIGHT 800

int main()
{
    // create a SDL object
    SDL sdl;
    // quit will control the main loop (game loop)
    bool quit = false;
    // Define the set of points to make a triangle
    Point2 pt[] = { Point2{100, 100}, Point2{50, 200}, 
        Point2{150,200} };
    // Define the set of points to make a rectangle
    Point2 pr[] = { Point2{200, 600}, Point2{200, 700}, 
        Point2{300,700}, Point2{300, 600} };
    // Create an instance of a triangle, calling constructor
    Triangle t{pt};
    // Create an instance of a rectangle, calling constructor
    Rectangle r{pr};
    // Create a Grid centered at (600, 600), 300
    // pixels by 200 pixels (width x height), 
    // 20 pixels between lines
    Grid g{ Point2{WIDTH/2, HEIGHT/2}, WIDTH, HEIGHT, 200, 200};

    // Creating an arrow with tail at (150,150) and head at (400,150)
    Arrow2 arrow{ Point2{150, 150}, Point2{400, 150} };
    // A new circle centered at (150, 270}, radius equals to 100 pixels
    // and 60 points for drawing
    Circle c{ Point2{150.0, 270.0}, 100.0, 60};

    // Event handler, it'll handle keyboard and mouse events
    SDL_Event e;

    double angle = 0.0;

    // new scope to control when the window w will be destroyed
    {
        Window w(WIDTH, HEIGHT);
        // main loop
        while (!quit) 
        {
            // Handle events on event queue
            while(SDL_PollEvent(&e) != 0)
            {
                // User requests quit
                if(e.type == SDL_QUIT)
                    quit = true;
                // Keydown Event
                if(e.type == SDL_KEYDOWN)
                {       
                    // if's to select the action to be executed
                    if (e.key.keysym.sym == SDLK_LEFT)
                        c.translate(-5, 0);
                    if (e.key.keysym.sym == SDLK_DOWN)
                        c.translate(0, +5);
                    if (e.key.keysym.sym == SDLK_RIGHT)
                        c.translate(+5, 0);
                    if (e.key.keysym.sym == SDLK_UP)
                        c.translate(0, -5);
                    // pressing q will exit the main loop
                    if (e.key.keysym.sym == SDLK_q)
                        quit = true;
                }
            }
            // clear surface before draw
            w.clear();

            // draw a rotating line at center
            w.drawLine(3*WIDTH/4, HEIGHT/4,
                    3*WIDTH/4+100*cos(angle), 
                    HEIGHT/4+100*sin(angle));

            // rotating arrow 
            Arrow2 ra(3*WIDTH/4, HEIGHT/4,
                    3*WIDTH/4+100*cos(angle), 
                    HEIGHT/4+100*sin(angle));
            // drawing rotating arrow
            ra.draw(w);

            // control rotation speed of line
            angle += 0.001;

            // draw the triangle t
 //           t.draw(w);

            // draw the rectangle r
//            r.draw(w);

            // draw the grid g
            //g.draw(w);

            // draw the circle c
//            c.draw(w);
            //vec2.operator*=(w);
            // desenhar a seta
            //arrow.draw(w);
            // update renderer


            
            w.update();
            
        } // end of main loop
    } // end of a scope of window

    // return no error to the operating system
    return 0;
}
