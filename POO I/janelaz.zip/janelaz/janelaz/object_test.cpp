#include "vector2.h"
#include "object.h"
#include <iostream>
using namespace std;

int main()
{
    Vector2 r{0.0, 0.0};
    Vector2 v{2.0, 3.0};
    cout << "r = " << r << ", v = " << v << ", r + v = " << r+v << endl;
    Object o{ r, v };
    cout << "objeto antes do movimento " << endl;
    cout << o << endl;
    // move object for 0.1s 
    o.move(0.1);
    cout << "objeto após do movimento " << endl;
    cout << o << endl;
}

