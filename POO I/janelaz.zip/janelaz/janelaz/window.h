#ifndef J1_WINDOW_H
#define J1_WINDOW_H

#include <SDL.h>

#include "point2.h"

class Window 
{
    protected:
        int width;
        int height;
        //The window we'll be rendering to (pointer)
        SDL_Window * window;
        //The surface contained by the window (pointer)
        SDL_Surface * screenSurface;
        //The window renderer (pointer)
        SDL_Renderer * renderer = NULL;
    public:
        Window(int width, int height);
        ~Window();      

        void drawLine(int xi, int yi, int xf, int yf);
        void drawLine(Point2 pi, Point2 pf);
        void clear();
        void update();

};

#endif
