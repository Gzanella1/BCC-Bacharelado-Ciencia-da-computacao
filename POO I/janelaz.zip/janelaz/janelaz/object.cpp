#include "object.h"

Object::Object(const Vector2 &r, const Vector2 &v):
    r{r},
    v{v}
{
}
        
ostream & operator<<(ostream &o, const Object &obj)
{
    o << "Object at " << obj.r << 
        ", velocity = " << obj.v;
    return o;
}


void Object::move(double dt)
{
    r += (dt * v);
}
