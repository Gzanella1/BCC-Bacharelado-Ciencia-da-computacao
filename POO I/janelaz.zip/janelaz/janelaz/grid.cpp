#include "grid.h"
#include <iostream>
using namespace std;

Grid::Grid(const Point2 &o, int w, int h, int dx, int dy):
    o{o}, w{w}, h{h},
    dx{dx}, dy{dy}
{ }

void Grid::draw(Window &w)
{
    // drawing a horizontal line through origin
    w.drawLine(o.x - Grid::w/2, o.y, o.x + Grid::w/2, o.y);
    // drawing a vertical line through origin
    w.drawLine(o.x, o.y-Grid::h/2,o.x, o.y+Grid::h/2);
    // drawing vertical lines
    for (int i = dx; i <= Grid::w/2; i += dx)
    {
        w.drawLine(o.x+i, o.y-h/2, o.x+i,o.y+h/2);
        w.drawLine(o.x-i, o.y-h/2, o.x-i,o.y+h/2);
    }
    // drawing horizontal lines
    for (int i = dy; i <= Grid::h/2; i += dy)
    {
        w.drawLine(o.x-Grid::w/2, o.y+i , o.x+Grid::w/2, o.y+i);
        w.drawLine(o.x-Grid::w/2, o.y-i , o.x+Grid::w/2, o.y-i);
    }
}
        
void Grid::translate(double x, double y)
{
    o.translate(x,y);
}
