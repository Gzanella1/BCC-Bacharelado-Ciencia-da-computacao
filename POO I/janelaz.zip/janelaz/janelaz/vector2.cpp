#include "vector2.h"
// construtor   
Vector2::Vector2():
    //iniciar as variaveis
    x{0.0}, y{0.0}
{ }

Vector2::Vector2(double x, double y):
    x{x}, y{y}
{
}

Vector2 Vector2::operator+=(const Vector2 &u)
{
    x += u.x;
    y += u.y;
    return *this;
}
        
Vector2 Vector2::operator+(const Vector2 &u)
{
    Vector2 tmp(*this);
    return tmp += u;
}

Vector2 Vector2::operator*=(double s)
{
    x *= s;
    y *= s;
    return *this;
}

Vector2 operator*(double s, const Vector2 &u)
{
    Vector2 tmp(u);
    tmp *= s;
    return tmp;
}

Vector2 operator*(const Vector2 &u, double s)
{
    Vector2 tmp(u);
    tmp *= s;
    return tmp;
}

ostream & operator<<(ostream &o, const Vector2 &u)
{
    o << "<" << u.x << "," << u.y << ">";
    return o;
}
