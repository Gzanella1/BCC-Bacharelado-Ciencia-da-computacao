#include "circle.h"

Circle::Circle(const Point2 &c, double r, ssize_t n):
    c{c},
    r{r},
    n{n},
    ps{nullptr}
{
    //  novo armazenamento para n pontos bidimensionais
    //  n -> é o numeros de pontos do circulo
    ps = new Point2[n];
    const double incA = 2*M_PI/n;
    double a = 0.0;
    for (int i = 0; i < n; i++, a += incA)
        ps[i] = Point2(c.x + r * cos(a), c.y + r * sin(a) );
}

Circle::~Circle(){
    // freeing storage used for points
    if (ps != nullptr)
        delete [] ps;
    ps = nullptr;
}
        
void Circle::draw(Window &w)
{
    for (int i = 0; i < n; i++)
        w.drawLine(ps[i%n], ps[(i+1)%n]);
}

void Circle::translate(double x, double y)
{
    for (int i = 0; i < n; i++)
        ps[i].translate(x, y);
}

