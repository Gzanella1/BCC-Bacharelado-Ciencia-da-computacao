#ifndef J1_VECTOR2_H
#define J1_VECTOR2_H

#include "point2.h"
#include "window.h"
#include <sstream>
using namespace std;

class Vector2 {
    public:
        double x;
        double y;
        Vector2();
        Vector2(double x, double y);
        Vector2 operator+=(const Vector2 &u);
        Vector2 operator+(const Vector2 &u);
        Vector2 operator*=(double s);
        friend Vector2 operator*(double s, const Vector2 &u);
        friend Vector2 operator*(const Vector2 &u, double s);
        friend ostream & operator<<(ostream &o, const Vector2 &u);

};

#endif
