#ifndef J1_RECTANGLE_H
#define J1_RECTANGLE_H

#include "point2.h"
#include "window.h"

class Rectangle {
    public:
        bool hidden;
        Point2 p[4];
        Rectangle(Point2 p[]);
        void draw(Window &w);
        void translate(double x, double y);
        void hide();
        void show();
};

#endif
