#ifndef J1_POINT2_H
#define J1_POINT2_H

class Point2 {
    public:
        double x;
        double y;
        // default constructor, setting values to 0,0
        Point2();  
        Point2(double x, double y);
        Point2(const Point2 &p);
        Point2 & operator=(const Point2 &p);
        void translate(double x, double y);
        void moveTo(double x, double y);
};

#endif
