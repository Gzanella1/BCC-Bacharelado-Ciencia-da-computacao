#include "matriz.h"

Matriz::Matriz(int num_colunas, int num_linhas):
    n_colunas{num_colunas},
    n_linhas{num_linhas}
{
    valores = new double*[n_linhas];

    for(int i = 0; i < n_linhas; ++i) {
        valores[i] = new double [n_colunas];

        for(int j = 0; j < )
    }
}


