#ifndef J1_GRID_H
#define J1_GRID_H

#include "point2.h"
#include "window.h"

class Grid {
    public:
        Point2 o; /// origin (center)
        int w; /// width   ->largura
        int h; /// height  -> altura
        int dx; /// distance between lines in x direction
        int dy; /// distance between lines in y direction
        Grid(const Point2 &o, int w, int h, int dx, int dy);
        void draw(Window &w);
        void translate(double x, double y);
};

#endif
