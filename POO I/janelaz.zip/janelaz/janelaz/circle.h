#ifndef J1_CIRCLE_H
#define J1_CIRCLE_H

#include "point2.h"
#include "window.h"

#define CIRCLE_NPOINTS 30

class Circle {
    public:
        Point2 c; // center
        double r; // radius
        ssize_t n; // the number of points used to draw the circle
        Point2 *ps; // storage para os pontos
        // Constructor with default parameter n = CIRCLE_NPOINTS
        Circle(const Point2 &c, double r, ssize_t n = CIRCLE_NPOINTS);
        ~Circle();
        void draw(Window &w);
        void translate(double x, double y);
};

#endif
