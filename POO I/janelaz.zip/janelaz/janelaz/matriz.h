#ifndef J1_MATRIZ_H
#define J1_MATRIZ_H

#include "point2.h"
#include "window.h"

class Matriz {
    public:
        //bool hidden; //escondido
        int n_colunas;
        int n_linhas;
        double **valores;
        Matriz(n_colunas, n_linhas);
        Matriz operator+(const Matriz &m);
        Matriz operator-(const Matriz &m);
        Matriz operator*(const Matriz &m); //matriz * matriz
        Matriz multiplicacao_escalar(const double num); //matriz * num
        void draw(Window &w);
        void translate(double x, double y);
        //void hide();
        //void show();
};

#endif
