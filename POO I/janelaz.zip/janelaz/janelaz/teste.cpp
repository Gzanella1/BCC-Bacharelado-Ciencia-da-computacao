#include "teste.h"
#include "point2.h"

#include <iostream>
using namespace std;

// constructor
Teste::Teste(double tx, double ty):
        //inicializando as variaveis cauda e cabeça da seta
        tail{tx, ty}
{
}

// constructor 
Teste::Teste(const Point2 &tail, const Point2 &head):
    //inicializando as variaveis
    tail{tail},
    head{head}
{
}
int *ponteiro;

void Teste::draw(Window &w){
    // calculating the size of the arrow head, 10%
    // calculando o tamanho da ponta da seta, 10%
    // se aumentar o valor de 0.1 a cabeça da seta aumenta
    double l = 0.1;

    // calculating the angle
    // calculando o angulo
    double angulo = atan2(head.y - tail.y, head.x - tail.x);
    w.drawLine(tail, head);

    // drawing head
    // desenha a cabeça
    w.drawLine(head.x, head.y, 
               head.x + l*cos(angulo +3*M_PI/4), 
               head.y + l*sin(angulo+3*M_PI/4) );
   
    w.drawLine(head.x, head.y, 
        head.x + l*cos(angulo +5 * M_PI/4), 
        head.y + l*sin(angulo +5 * M_PI/4) );
}

void Teste::translate(double x, double y){
    head.translate(x, y);
    tail.translate(x, y);
}





/*A função Atan2 retorna o arco tangente ou a tangente inversa de coordenadas x e y especificadas como argumentos. 
O arco tangente é o ângulo entre o eixo x para uma linha que contém a origem (0, 0) e um ponto com coordenadas (x, y).
O ângulo é fornecido em radianos entre -π e π, excluindo -π. Um resultado positivo representa um
ângulo no sentido anti-horário a partir do eixo x. Um resultado negativo apresenta um ângulo no sentido horário.
Atan2(a,b) é igual a Atan(b/a), exceto que a pode ser igual a 0 (zero) com a função Atan2.*/


/*
o que é targuet => programa em si

*/