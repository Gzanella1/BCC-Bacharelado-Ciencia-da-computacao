#ifndef J1_SDL_H
#define J1_SDL_H

class SDL {
    public:
        SDL();
        ~SDL();
    private:
        bool init();
        bool quit();
};

#endif
