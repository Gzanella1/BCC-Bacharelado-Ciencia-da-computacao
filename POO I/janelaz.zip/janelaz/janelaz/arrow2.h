#ifndef J1_ARROW2_H
#define J1_ARROW2_H

#include "point2.h"
#include "window.h"

class Arrow2 {
    public:
        Point2 tail; // arrow tail  -> cauda da seta
        Point2 head; // arrow head  -> cabeça da seta 
        // tail de (x,y) head (x,y)
        Arrow2(double tx, double ty, double hx, double hy);
        Arrow2(const Point2 &tail, const Point2 &head);
        void draw(Window &w);
        void translate(double x, double y);
        double length();
};

#endif
