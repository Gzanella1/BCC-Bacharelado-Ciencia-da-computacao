#include "rectangle.h"

Rectangle::Rectangle(Point2 p[]):
    hidden{false}
{
    for (int i = 0; i < 4; i++)
        Rectangle::p[i] = p[i];	
}

void Rectangle::draw(Window &w)
{
    if (!hidden) {
        w.drawLine(p[0], p[1]);
        w.drawLine(p[1], p[2]);
        w.drawLine(p[2], p[3]);
        w.drawLine(p[3], p[0]);
    }
}
        
void Rectangle::translate(double x, double y)
{
     for (int i = 0; i < 4; i++)
        p[i].translate(x,y);
}


void Rectangle::hide()
{
    hidden = true;
}

void Rectangle::show()
{
    hidden = false;
}
