#ifndef J1_teste_H
#define J1_teste_H

#include "point2.h"
#include "window.h"

class Teste {
    public:
        Point2 tail; // arrow tail  -> cauda da seta
        Point2 head; // arrow head  -> cabeça da seta 
        // tail de (x,y) head (x,y)
        Teste(const Point2 &tail, const Point2 &head);
        void draw(Window &w);
        Teste(double tx, double ty);
        void translate(double x, double y);
};

#endif