#ifndef J1_OBJECT_H
#define J1_OBJECT_H

#include "vector2.h"
#include "window.h"
#include <sstream>
using namespace std;

class Object {
    public:
        Vector2 r; // position
        Vector2 v; // velocity
        Object(const Vector2 &r, const Vector2 &v);
        friend ostream & operator<<(ostream &o, const Object &obj);
        // move object at position r to v direction for time dt
        // r = r + dt * v
        void move(double dt);
};

#endif
