#include "triangle.h"

/**
 * Constructor, the points stored at the parameter p[] will be
 * stored in (copied to) Triangle::p[] data member
 **/
Triangle::Triangle(Point2 p[])
{
    Triangle::p[0] = p[0];
    Triangle::p[1] = p[1];
    Triangle::p[2] = p[2];
}

void Triangle::draw(Window &w)
{
    w.drawLine(p[0], p[1]);
    w.drawLine(p[1], p[2]);
    w.drawLine(p[2], p[0]);
}

void Triangle::translate(double x, double y)
{
    for (int i = 0; i < 3; i++)
        p[i].translate(x, y);
}
