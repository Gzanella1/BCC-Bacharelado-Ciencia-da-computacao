#ifndef J1_TRIANGLE_H
#define J1_TRIANGLE_H

#include "point2.h"
#include "window.h"

class Triangle {
    public:
        Point2 p[3];
        Triangle(Point2 p[]);
        void draw(Window &w);
        void translate(double x, double y);
};

#endif
